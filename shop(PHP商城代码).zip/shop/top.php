<?php
   session_start();
   include("conn/conn.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�������̳�</title>
<link rel="stylesheet" type="text/css" href="css/font.css">
</head>
<body>
<table width="766" border="0" align="center" cellpadding="0" cellspacing="0" background="images/bannerdi.gif">
  <tr>
    <td colspan="3" valign="bottom"><table width="766" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="224" height="83">&nbsp;</td>
        <td align="right"><p>&nbsp;</p>
          <table height="20" border="0" align="center" cellpadding="0" cellspacing="0">
              
</table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td width="568" height="32" bgcolor="#E7E7E8">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php">�ס���ҳ</a>&nbsp;| <a href="shownewpr.php">���»�ɴ</a> | <a href="showtuijian.php">�Ƽ�Ʒ��</a> | <a href="showhot.php">����Ʒ��</a>&nbsp;|&nbsp;<a href="showfenlei.php">��Ʒ����</a>&nbsp;|&nbsp;<a href="usercenter.php">�û�����</a>&nbsp;|&nbsp;<a href="finddd.php">������ѯ</a>&nbsp;|&nbsp;<a href="gouwuche.php">���ﳵ</a></td>
    <td width="121" align="center" bgcolor="#E7E7E8">
      <?php
	  if($_SESSION[username]!=""){
	    echo "�û�:$_SESSION[username]��ӭ��";
	  }
	?>
    </td>
    <td width="77" bgcolor="#E7E7E8"> 
	<?php
	if($_SESSION[username]!=""){
	    echo "<a href='logout.php'>ע���뿪</a>";
	  }
	?>
    </td>
  </tr>
</table>	

