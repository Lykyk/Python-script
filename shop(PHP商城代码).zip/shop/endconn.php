<?php
mysql_close();
?>