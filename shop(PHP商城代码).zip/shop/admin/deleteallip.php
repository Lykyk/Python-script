<?php
include("conn/conn.php");
mysql_query("delete from tb_ip",$conn);
echo "<script>alert('�ÿͼ�¼����ɹ�!');history.back();</script>";
?>